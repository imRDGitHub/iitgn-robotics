#Kshitija Anam 18110087

import numpy as np

px = float(input("px: "))
py = float(input("py: "))
pz = float(input("pz: "))

a1 = float(input("a1: "))
a2 = float(input("a2: "))

d4 = float(input("d4: "))

alpha = np.radians(float(input("alpha in degrees: ")))

r = np.sqrt((((px**2)+(py**2)-(a1**2)-(a2**2))/(2*a1*a2)))
temp = np.sqrt(1-(r**2))

theta2 = np.arctan2(temp,r)

temp1 = a1 + (a2*np.cos(theta2))
temp2 = a2*np.sin(theta2)

theta1 = np.arctan2(px,py) - np.arctan2(temp1, temp2)

theta4 = theta1 + theta2 - alpha

d3 = pz + d4

print("theta1: {} and {}".format(np.degrees(theta1), np.degrees(theta1 + np.pi)))
print("theta2: {} and {}".format(np.degrees(theta2), np.degrees(-theta2 + np.pi)))
print("d3: {}".format(d3))
print("theta4: {}".format(np.degrees(theta4)))
