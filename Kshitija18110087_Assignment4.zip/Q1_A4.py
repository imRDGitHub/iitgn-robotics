#Kshitija Anam 18110087

import numpy as np

px = float(input("px: "))
py = float(input("py: "))
pz = float(input("pz: "))

d1 = float(input("d1: "))
d2 = float(input("d2: "))

r = np.sqrt(((px**2)+(py**2)))
s = pz - d1

theta1 = np.arctan2(px,py)
theta2 = np.arctan2(r,s)

d3 = np.sqrt(((r**2)+(s**2))) - d2