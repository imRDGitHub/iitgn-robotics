import math

#The U matrix has to be given to find the Euler angles

def invKineSphericalWrist(U):
    if U[0][2]!=0 or U[1][2]!=0 :
        i = int(input("Enter 1 for sin_theta > 0 or 0 for sin_theta <0 :"))
        if i == 1:
            theta = math.atan2(math.sqrt(1-U[2][2]*U[2][2]),U[2][2])
            phi = math.atan2(U[1][2],U[0][2])
            psi = math.atan2(U[2][1],-U[2][0])
        elif i == 0:
            theta = math.atan2(-math.sqrt(1-U[2][2]*U[2][2]),U[2][2])
            phi = math.atan2(-U[1][2],-U[0][2])
            psi = math.atan2(-U[2][1],U[2][0])
        else:
            print("Error!!! Restricted inputs allowed.")
    else:
        if U[2][2] == 1:
            theta = 0
            sum_phi_psi = math.atan2(U[1][0],U[0][0])
            #Here there can be infinitely many solutions, thus we take
            phi = 0; #by convention
            psi = sum_phi_psi - phi
        elif U[2][2] == -1:
            theta = math.pi
            diff_phi_psi = math.atan2(-U[0][1],-U[0][0])
            #As before, again we can have infinitely many solutions. Thus, we consider
            phi = 0
            psi = phi - diff_phi_psi
        else:
            print("Error!!! The input matrix is invalid.")
    theta = theta*180/math.pi
    phi = phi*180/math.pi
    psi = psi*180/math.pi
    print("The Euler angles theta, phi and psi respectivey are :",theta,phi,psi)

#Example Input :
#invKineSphericalWrist([(0.1,0.2,0.5),(0.3,0.4,0),(0,0,0.1)])