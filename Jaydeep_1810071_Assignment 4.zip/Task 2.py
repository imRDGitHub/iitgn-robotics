import math
    
# Rotation matrix R and end-effector position d are given
# a1 = length of link 1
# a2 = length of link 2
# d4 = distance between o3 and o4

def invKineSCARA(R,d,a1,a2,d4):
    r = math.sqrt((d[0]**2 + d[1]**2 - a1**2 - a2**2)/(2*a1*a2))
    theta_2 = math.atan(math.sqrt(1 - r**2)/r)
    # alternate theta_2 = math.atan(-math.sqrt(1-r**2)/r)
    theta_1 = math.atan((d[0]/d[1])) - math.atan((a1 + a2*math.cos(theta_2))/(a2*math.sin(theta_2)))
    alpha = math.atan((R[0][1]/R[0][0]))
    theta_4 = theta_1+theta_2-alpha
    d3 = d[2] + d4
    print("The value of Theta 1, Theta 2 and Theta 4 respectively are :", theta_1,theta_2,theta_4)
    print("The value of d3 = ",d3)

#Example Input
#invKineSCARA([(0.866,-0.5,0),(0.5,0.866,0),(0,0,1)],[3,4,5],4,4,2)