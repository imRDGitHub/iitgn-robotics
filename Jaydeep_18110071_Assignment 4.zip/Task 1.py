import math

# p is the end effector position
# d1 is the length of link 1
# a2 is the length of link 2

def invKineStanford(p,d1,a2):
    theta_1 = math.atan((p[0]/p[1]))
    r = math.sqrt((p[0]**2) + (p[1]**2))
    s = p[2] - d1
    theta_2 = math.atan((r/s))
    d3 = math.sqrt((r**2)+(s**2)) - a2
    theta_1 = theta_1*180/math.pi
    theta_2 = theta_2*180/math.pi
    print("The value of Theta 1 and Theta 2 respectively are ",theta_1,theta_2)
    print("The value of d3 = ",d3)

#Example input :
#invKineStanford([3,4,5],4,4)