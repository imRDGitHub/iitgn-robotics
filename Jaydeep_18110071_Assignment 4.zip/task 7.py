import numpy as np

#The class Jacobian has been written after referring from Harsh Mandalia's previous assignment submission.
#He has confirmed that I can use his code.

class Jacobian():
    
    def __init__(self) -> None:
        self.n = 0
        self.dh_para = []
        self.A = []
        self.o = []
        self.Z = []
        self.J = []
        self.R_or_P = []
        self.EE_pos = []
        pass

    def takeInputs(self):
        n = int(input("Number of links:"))
        dh_para = [0]*n
        R_or_P = [0]*n
        print("Link |   theta_i |   d_i |   a_i |   alpha_")
        for i in range(n):
            dh_para[i] = [eval(j) for j in input(str(i+1) + " "*6).split()]
        
        lst=[int(i) for i in input("Type the joint numbers of prismatic joints (leave empty if none): ").split()]

        for i in lst:
            R_or_P[i-1]=1
        self.n = n
        self.dh_para = dh_para
        self.A_matrix()
        self.R_or_P = R_or_P
        pass

    def A_matrix(self,):
        A = [0]*self.n
        for i in range(self.n):
            theta,d,a,alpha = self.dh_para[i]
            A[i] = np.array([[np.cos(theta), -np.sin(theta)*np.cos(alpha), np.sin(theta)*np.sin(alpha), a*np.cos(theta)],
                             [np.sin(theta), np.cos(theta)*np.cos(alpha), -np.cos(theta)*np.sin(alpha), a*np.sin(theta)],
                             [0, np.sin(alpha), np.cos(alpha), d],
                             [0, 0, 0, 1]])
        self.A = A
        self.o_and_z_matrix()
        pass
    
    def o_and_z_matrix(self,):
        EE_pos = np.identity(4)
        Z = [0]*(self.n +1)
        Z[0] = np.array([[0],[0],[1]])
        o = [0]*(self.n+1)
        o[0] = np.array([0,0,0])

        for i in range(self.n):
            EE_pos = EE_pos@self.A[i]
            Z[i+1]=EE_pos[0:3, 0:3]@Z[0]
            o[i+1]=EE_pos[0:3,3].T
        
        EE_pos = EE_pos[0:3,3]
        self.EE_pos = EE_pos
        self.o = o
        self.Z = Z
        self.calculateJ()
        pass

    def calculateJ(self,):
        J = [0]*self.n
        for i in range(self.n):
            if self.R_or_P[i] == 1:
                J[i] = np.concatenate((self.Z[i], np.array([[0,0,0]]).T), axis=0)
            else:
                cross=np.cross(self.Z[i].T,(self.o[self.n]-self.o[i]).T)
        J[i]=np.concatenate((cross.T,self.Z[i]),axis=0)

        final_J = J[0]
        for i in range(1, self.n):
            final_J = np.concatenate((final_J, J[i]), axis=1)

        self.J = final_J
        pass

    def callbackJ(self,):

        self.takeInputs()
        return self.J

class Task7(Jacobian):

    def calcEndEffectorVar(self):
        J = self.J
        q_d = [eval(j) for j in input("Enter q_dot as d1_dot d2_dot d3_dot: ").split()]
        EE_pos = self.EE_pos
        EE_vel = J@q_d
        return EE_pos, EE_vel      

a7 = Task7()
end_eff_pos, end_eff_vel = a7.calcEndEffectorVar()
print(end_eff_pos, end_eff_vel)